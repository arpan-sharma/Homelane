from django.db import models

# Create your models here.
from django_fsm import transition, FSMIntegerField

class StatusFor(models.Model):
    
    STATUS_CREATED = 0
    STATUS_Approved = 1
    STATUS_Rejected = 2

    STATUS_CHOICES = (
        (STATUS_CREATED, 'created'),
        (STATUS_Approved, 'Approved'),
        (STATUS_Rejected, 'Rejected'),
    )

    status = FSMIntegerField(choices=STATUS_CHOICES, default=STATUS_CREATED, protected=True)  
    main_status =models.CharField(max_length=122,default="Created")

    

    @transition(field=status, source=[STATUS_CREATED,STATUS_Approved], target=STATUS_Approved)
    def approved(self,approver_name):
        print(f"{approver_name} Approved Sucessfully")
        

    @transition(field=status, source=STATUS_Approved, target=STATUS_Rejected)
    def rejected(self,approver_name):
        print(f"{approver_name} Rejected Sucessfully")

