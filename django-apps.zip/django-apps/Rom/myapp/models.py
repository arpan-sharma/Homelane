from django.db import models

# Create your models here.
from django_fsm import transition, FSMIntegerField

class Status_for(models.Model):
    STATUS_CREATED = 0
    STATUS_A = 1
    STATUS_B = 2
    STATUS_C = 3
    STATUS_D = 4
    STATUS_CHOICES = (
        (STATUS_CREATED, 'created'),
        (STATUS_A, 'A_Approved'),
        (STATUS_B, 'B_Approved'),
        (STATUS_C, 'C_Approved'),
        (STATUS_D, 'D_Approved'),
    )

    status = FSMIntegerField(choices=STATUS_CHOICES, default=STATUS_CREATED, protected=True)  

    @transition(field=status, source=STATUS_CREATED, target=STATUS_A)
    def a_approved(self):
        print("A Approved Sucessfully") 

    @transition(field=status, source=STATUS_A, target=STATUS_B)
    def b_approved(self):
        print("B Approved Sucessfully") 

    @transition(field=status, source=STATUS_B, target=STATUS_C)
    def c_approved(self):
        print("C Approved Sucessfully")   

    @transition(field=status, source=STATUS_C, target=STATUS_D)
    def d_approved(self):
        print("D Approved Sucessfully")