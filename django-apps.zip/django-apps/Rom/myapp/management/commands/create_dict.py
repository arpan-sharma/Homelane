from django.core.management.base import BaseCommand
import os

class Command(BaseCommand):
	help = 'This Command Will Create Dictionary'

	def handle(self,*args,**kwargs):
		all_files = ['views','serializers','services','models']
		path = os.path.abspath(os.getcwd())

		for i in all_files:
			isFile = os.path.isfile(path+'/'+i+'/'+'__init__.py')
			if isFile == False:
				dic = os.mkdir(path+'/'+i)
				fo = open(path+'/'+i+'/'+'__init__.py', "wb")
				fo.close()
			else:
				print("Already Satisfied")





