from django.core.management.base import BaseCommand
import os

class Command(BaseCommand):
	help = 'This Command Will Create Dictionary'


	def add_arguments(self, parser):
		parser.add_argument('name')

	def handle(self, *args, **options):
		app_name = options['name']
		all_files = ['views','models','services','serializers']
		main_path = os.path.abspath(os.getcwd()) + '/'+ app_name

		for i in all_files:
			isFile = os.path.exists(main_path+'/'+i)
			if isFile == False:
				dic = os.mkdir(main_path+'/'+i)
				fo = open(main_path+'/'+i+'/'+'__init__.py', "wb")
				if os.path.isfile(main_path+'/'+i+'.py'):
					os.replace(main_path+'/'+i+'.py', main_path+'/'+i+'/'+i+'.py')
					fo.close()
				else:
					print("All Done")
			else:
				print("All Done")





