from django.shortcuts import render, HttpResponse
from django.http import JsonResponse

def get_response(message="", data={}, error=[], success=False):
   return {

      "success" : success,
      "error": error,
      "data": data,
      "message" : message,
   }

def index(request):
	return HttpResponse("This Is Home page")
	

def values(request):
	response = get_response(
               message="Result Present",
               error= None,
               data = {
                 "id": "1",
                 "name": "Arpan",
                 "Department": "Tech.",
                 },
                success = True
           )
	return JsonResponse(response)

