from django.shortcuts import render
from django.http import HttpResponse
from django.core.serializers import serialize
from .models import ApiTestModel
import json

# Create your views here.
def index(request):
	q = ApiTestModel.objects.all()
	if q != None:
		val = serialize('json',q,fields=('id','title'))
		response_data = {}
		response_data['success'] = True,
		response_data['error'] = [],
		response_data['data'] = val,
		response_data['message'] = 'Result Present',
		return HttpResponse(json.dumps(response_data), content_type="application/json")
	else:
		response_data = []
		response_data['success'] = False,
		response_data['error'] = [],
		response_data['data'] = [],
		response_data['message'] = 'Result Not Present',
		return HttpResponse(json.dumps(response_data), content_type="application/json")

	# return HttpResponse("This Is Home page")
