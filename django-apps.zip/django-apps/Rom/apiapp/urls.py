from django.urls import path , include 
from apiapp import views


urlpatterns = [
    path('', views.index,name='index'),
    path('data', views.values,name='values')
]

