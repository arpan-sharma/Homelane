from django.contrib import admin
from apiapp.models import ApiTestModel

# Register your models here.
admin.site.register(ApiTestModel)